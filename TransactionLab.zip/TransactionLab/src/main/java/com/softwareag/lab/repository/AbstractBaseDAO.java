/**
 * 
 */
package com.softwareag.lab.repository;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.Collection;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

/**
 * The Class AbstractBaseDAO is a default implementation of {@link IBaseDAO) provided by the
 * platform. This implementation internally uses {@link HibernateDaoSupport} to make the data access
 * generic to query any type of entity.
 * 
 * This class is convenient super class for platform DAO (Data Access Object) implementation by
 * providing an abstraction over {@link HibernateDaoSupport} to decouple platform code from
 * {@link HibernateDaoSupport}.
 * 
 * Each module specific DAO layer is expected to extend {@link IBaseDAO} for DAO interface and
 * implement {@link AbstractBaseDAO} for DAO implementation.
 *
 * @author SYAB
 * @param <T> the generic type
 */
public abstract class AbstractBaseDAO<T> extends HibernateDaoSupport implements IBaseDAO<T> {

    /** The logger. */
    private static Logger logger = LogManager.getLogger(AbstractBaseDAO.class);

    /** The entity class. */
    private Class<T> entityClass;

    /** The entity name. */
    private String entityName;

    /** The session factory. */
    protected SessionFactory sessionFactory;

    /**
     * Sets the session.
     *
     * @param sessionFactory the Hibernate SessionFactory
     */
    @Autowired
    @Qualifier("sessionFactory")
    public void setSession(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        this.setSessionFactory(sessionFactory);
    }

    /**
     * Instantiates a new abstract base DAO.
     */
    @SuppressWarnings("unchecked")
    public AbstractBaseDAO() {
        entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        entityName = entityClass.getName();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#create(java.lang.Object)
     */
    @Override
    public Serializable create(T entity) {
        logger.debug("Creating instance of " + entityName + ". Entity: " + entity);
        Serializable identifier = getHibernateTemplate().save(entity);
        logger.debug("Created instance of " + entityName + ". Entity: " + entity);
        return identifier;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#read(java.lang.String)
     */
    @Override
    public T read(Serializable id) {
        logger.debug("Reading instance of " + entityName + " with Identifier " + id);
        T entity = (T) getHibernateTemplate().get(entityClass, id);
        logger.debug("Retrieved instance of " + entityName + ". Entity: " + entity);
        return entity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#update(java.lang.Object)
     */
    @Override
    public void update(T entity) {
        logger.debug("Updating instance of " + entityName + ". Entity: " + entity);
        getHibernateTemplate().update(entity);
        logger.debug("Updated instance of " + entityName + ". Entity: " + entity);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#delete(java.lang.Object)
     */
    @Override
    public void delete(T entity) {
        logger.debug("Deleting instance of " + entityName + ". Entity: " + entity);
        getHibernateTemplate().delete(entity);
        logger.debug("Deleted instance of " + entityName + ". Entity: " + entity);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#createOrUpdate(java.lang.Object)
     */
    @Override
    public void createOrUpdate(T entity) {
        logger.debug("Creating/Updating instance of " + entityName + ". Entity: " + entity);
        getHibernateTemplate().saveOrUpdate(entity);
        logger.debug("Created/Updated instance of " + entityName + ". Entity: " + entity);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.common.IBaseDAO#load(java.io.Serializable)
     */
    @Override
    public T load(Serializable id) {
        logger.debug("Loading instance of " + entityName + " with Identifier " + id);
        T entity = (T) getHibernateTemplate().load(entityClass, id);
        logger.debug("Loaded instance of " + entityName + ". Entity: " + entity);
        return entity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#list()
     */
    @Override
    public Collection<T> list() {
        logger.debug("Fetching instance list of " + entityName);
        Collection<T> entityList = getHibernateTemplate().loadAll(entityClass);
        logger.debug("Fetched instance list of " + entityName + ". Record Count: " + entityList != null ? entityList.size() : 0);
        return entityList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#list(org.hibernate.criterion.DetachedCriteria)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Collection<T> list(DetachedCriteria criteria) {
        logger.debug("Fetching instance list of " + entityName + " with Criteria: " + criteria);
        List<T> entityList = (List<T>) getHibernateTemplate().findByCriteria(criteria);
        logger.debug(
                "Fetched instance list of " + entityName + " with Criteria: " + criteria + ". Record Count: " + entityList != null ? entityList.size()
                        : 0);
        return entityList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.agileapps.core.repository.IBaseDAO#merge(java.lang.Object)
     */
    @Override
    public T merge(T entity) {
        logger.info("Merging instances of" + entityName + ". Entity: " + entity);
        entity = (T) getHibernateTemplate().merge(entity);
        logger.info("Merger instances of " + entityName + " .Entity: " + entity);
        return entity;
    }



}
