package com.softwareag.lab.controller;

import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.softwareag.lab.service.EmployeeBean;
import com.softwareag.lab.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    
    @Autowired
    @Qualifier("employeeService")
    private EmployeeService employeeService;
    
    @RequestMapping(method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    public Object create(@RequestBody Map<String, Object> requestMap) {
        EmployeeBean employeeBean = new EmployeeBean();
        Integer id = new Random().nextInt(100);
        employeeBean.setId(id);
        employeeBean.setEmployeeName((String) requestMap.get("name"));
        employeeBean.setDesignation((String) requestMap.get("designation"));
        employeeService.create(employeeBean);
        return requestMap;
    }

    @RequestMapping(value = "/{employeeId}", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
    public Object getRecord(@PathVariable(value = "employeeId") String employeeId) {
        return employeeService.read(Integer.parseInt(employeeId));
    }

    @RequestMapping(value = "/{employeeId}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public Object updateRecord(@PathVariable(value = "employeeId") String employeeId, @RequestBody Map<String, Object> requestMap) {
        return requestMap;
    }


    @RequestMapping(value = "/{employeeId}", method = RequestMethod.DELETE)
    public void deleteRecord(@PathVariable(value = "employeeId") String employeeId) {}

}
