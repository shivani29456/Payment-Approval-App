package com.softwareag.lab.repository;

import org.springframework.stereotype.Repository;


@Repository("employeeDAO")
public class EmployeeDAO extends AbstractBaseDAO<EmployeeEntity>  {

}