/**
 * 
 */
package com.softwareag.lab.repository;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.criterion.DetachedCriteria;

/**
 * The Interface IBaseDAO is a convenient base interface which declares the common set of data
 * access APIs required for platform DAO (Data Access Objects) layers. All module specific DAO layer
 * interface should extend from it.
 * 
 * Note: Platform provides a default implementation {@link AbstractBaseDAO} which implements all the
 * base contracts so as to enable the module specific DAOs to avoid repeated implementation of
 * primary data access operations.
 * 
 * Each module specific DAO layer is expected to extend {@link IBaseDAO} for DAO interface and
 * implement {@link AbstractBaseDAO} for DAO implementation.
 *
 * @author SYAB
 * @param <T> the generic type
 */
public interface IBaseDAO<T> {

    /**
     * Persist the given transient instance.
     *
     * @param entity the transient instance to persist
     * @return the entity identifier
     */
    public Serializable create(T entity);

    /**
     * Return the persistent instance of the given entity class with the given identifier or null if
     * there is no such persistent instance. If the instance is already associated with the session
     * (Session Cache), return that instance. This method never returns an uninitialized/proxied
     * instance.
     * 
     * Performs database hit if object doesn't exists in Session Cache and returns a fully initialized
     * object which may further involve several database calls.
     * 
     * Use this API when we want to make sure data exists in the database and to perform alternate
     * action if date does not exist.
     * 
     * @param id the identifier of the persistent instance
     * @return the persistent instance, or null if not found
     */
    public T read(Serializable id);

    /**
     * Update the given persistent instance.
     *
     * @param entity the persistent instance to update
     */
    public void update(T entity);

    /**
     * Delete the given persistent instance.
     *
     * @param entity the persistent instance to delete
     */
    public void delete(T entity);

    /**
     * Save or Update the given persistent instance depends on the entity availability refering to the
     * entity id
     *
     * @param entity the transient/persistent instance to Save/Update
     */
    public void createOrUpdate(T entity);

    /**
     * Return the persistent instance of the given entity class with the given identifier, assuming that
     * the instance exists. This method might return a proxied instance that is initialized on-demand,
     * when a non-identifier method is accessed.
     * 
     * As this API might return proxied instance for which actual entity with the given identifier may
     * not actually exists, it loads the data from database or cache only when non-identifier properties
     * accessed and will throw ObjectNotFoundException if the persistence entity is unavailable.
     * 
     * You should not use this method to determine if an instance exists (use get()instead). Use this
     * only to retrieve an instance that you assume exists, where non-existence of the entity needs to
     * be treated as error.
     * 
     * @param id the identifier of the persistent instance
     * @return the persistent instance, or null if not found
     */
    public T load(Serializable id);

    /**
     * Return all persistent instances of the given entity class.
     * 
     * Note: Use Overloaded method which takes Criteria as argument for retrieving a specific subset.
     *
     * @return 0 or more persistent instances
     */
    public Collection<T> list();

    /**
     * Execute a query based on a given Hibernate criteria object.
     *
     * @param criteria the detached Hibernate criteria object
     * @return 0 or more persistent instances
     */
    public Collection<T> list(DetachedCriteria criteria);

    /**
     * Merge two entities with same identifier. This method is used when an entity is read at one place
     * and updated at other places. It merges the old entity and the updated entity so that the old
     * entity is updated with the new values
     * 
     * @param entity The updated entity to merge
     */
    public T merge(T entity);

}
