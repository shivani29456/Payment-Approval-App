package com.softwareag.lab.service;

import com.softwareag.lab.repository.EmployeeEntity;

public class EmployeeBean {
    Integer id;
    String employeeName;
    String designation;

    public EmployeeBean() {}

    public EmployeeBean(EmployeeEntity entity) {
        this.id = entity.getId();
        this.employeeName = entity.getName();
        this.designation = entity.getDesignation();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

}
