package com.softwareag.lab.repository;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.softwareag.lab.service.EmployeeBean;

@Entity
@Table(name = "EMPLOYEE")
public class EmployeeEntity implements Serializable {
    
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "id",nullable = false)
    private Integer id;
    
    @Column(name = "name",nullable = false)
    private String name;
    
    @Column(name = "designation", nullable = false)
    private String designation;

    public EmployeeEntity() {}
    
    public EmployeeEntity(EmployeeBean bean) {
        this.id = bean.getId();
        this.name = bean.getEmployeeName();
        this.designation = bean.getDesignation();
        
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    
}

