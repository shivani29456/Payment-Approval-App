package com.softwareag.lab.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softwareag.lab.repository.EmployeeDAO;
import com.softwareag.lab.repository.EmployeeEntity;

@Service("employeeService")
public class EmployeeService {
    
    @Autowired
    private EmployeeDAO employeeDAO;
    
    @Transactional
    public void create(EmployeeBean bean) {
        EmployeeEntity entity = new EmployeeEntity(bean);
        employeeDAO.create(entity);
    }
    
    public EmployeeBean read(Integer id) {
        EmployeeEntity entity= employeeDAO.read(id);
        EmployeeBean bean = new EmployeeBean(entity);
        return bean;
    }

    public void delete() {
    }
}
