package com.softwareag.lab.config;

import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

/**
 * The Class PlatformCoreConfiguration is Spring programmatic configuration class to create required
 * configuration for core module of platform
 * 
 * @author AKSI
 *
 */
@Configuration
public class PlatformCoreConfiguration {

    @Bean("dataSource")
    public BasicDataSource getDataSource() {
        BasicDataSource datasource = new BasicDataSource();
        datasource.setDriverClassName("com.mysql.jdbc.Driver");
        datasource.setUrl("jdbc:mysql://localhost:3306/sample");
        datasource.setUsername("root");
        datasource.setPassword("root");
        datasource.setMaxTotal(100);
        datasource.setMaxWaitMillis(3000);
        return datasource;
    }

    @Bean("sessionFactory")
    public LocalSessionFactoryBean getSessionFactory() {
        Properties sessionFactoryProperties = new Properties();
        sessionFactoryProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        sessionFactoryProperties.setProperty("hibernate.show_sql", String.valueOf(true));
        
        LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
        localSessionFactoryBean.setHibernateProperties(sessionFactoryProperties);
        localSessionFactoryBean.setDataSource(getDataSource());
        localSessionFactoryBean.setPackagesToScan("com.softwareag");
        return localSessionFactoryBean;
    }

    @Bean("transactionManager")
    public HibernateTransactionManager getHibernateTransactionManager(@Qualifier("sessionFactory") SessionFactory sessionFactory) {
        HibernateTransactionManager hibernateTransactionManager = new HibernateTransactionManager();
        hibernateTransactionManager.setSessionFactory(sessionFactory);
        return hibernateTransactionManager;
    }

}
